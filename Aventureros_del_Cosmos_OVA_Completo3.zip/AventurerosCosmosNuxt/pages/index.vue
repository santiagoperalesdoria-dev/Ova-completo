<script setup>
import { computed, ref } from 'vue'
import CosmicIcon from '~/components/CosmicIcon.vue'

const menuOpen = ref(false)
const selectedPlanet = ref(null)
const memoryOpen = ref(false)
const memoryCards = ref([])
const firstCard = ref(null)
const locked = ref(false)
const matches = ref(0)
const quizIndex = ref(0)
const chosenAnswer = ref(null)
const quizFinished = ref(false)
const score = ref(0)

const planets = [
  { name:'Mercurio', subtitle:'El más cercano al Sol', color:'mercury', icon:'●', title:'Mercurio', text:'Es el planeta más cercano al Sol y el más pequeño de nuestro sistema solar. Su superficie tiene muchos cráteres.' },
  { name:'Venus', subtitle:'Un mundo muy caliente', color:'venus', icon:'●', title:'Venus', text:'Venus es el planeta más caliente. Tiene una atmósfera muy densa y gira en dirección contraria a la mayoría de los planetas.' },
  { name:'Tierra', subtitle:'Nuestro hogar azul', color:'earth', icon:'globe', title:'La Tierra', text:'¡Nuestro hogar! Es el único planeta conocido que alberga vida y tiene agua líquida en su superficie.' },
  { name:'Marte', subtitle:'El planeta rojo', color:'mars', icon:'●', title:'Marte', text:'Se conoce como el planeta rojo por el color de su superficie. Los científicos estudian Marte para conocer más sobre su pasado.' },
  { name:'Júpiter', subtitle:'El gigante del sistema', color:'jupiter', icon:'●', title:'Júpiter', text:'Es el planeta más grande del sistema solar. Tiene una enorme tormenta conocida como la Gran Mancha Roja.' },
  { name:'Saturno', subtitle:'Famoso por sus anillos', color:'saturn', icon:'planet', title:'Saturno', text:'Es famoso por su impresionante sistema de anillos, formados principalmente por fragmentos de hielo y roca.' },
  { name:'Urano', subtitle:'Gira muy inclinado', color:'uranus', icon:'●', title:'Urano', text:'Es un gigante helado de color azul verdoso. Su eje está muy inclinado, por lo que parece girar de lado.' },
  { name:'Neptuno', subtitle:'Un mundo azul y lejano', color:'neptune', icon:'●', title:'Neptuno', text:'Es un planeta muy lejano, de color azul. En su atmósfera se producen vientos extremadamente rápidos.' }
]
const questions = [
  { q:'¿Cuál es el planeta donde vivimos?', answers:['Marte','Tierra','Venus'], correct:1, explain:'¡Correcto! La Tierra es nuestro hogar.' },
  { q:'¿Qué planeta es famoso por sus anillos?', answers:['Saturno','Neptuno','Mercurio'], correct:0, explain:'¡Muy bien! Saturno es famoso por su sistema de anillos.' },
  { q:'¿Cuál es el planeta más grande del sistema solar?', answers:['Marte','Tierra','Júpiter'], correct:2, explain:'¡Exacto! Júpiter es el planeta más grande.' },
  { q:'¿Qué estrella está en el centro del sistema solar?', answers:['La Luna','El Sol','Sirio'], correct:1, explain:'¡Así es! El Sol es la estrella del centro de nuestro sistema solar.' },
  { q:'¿Qué planeta es conocido como el planeta rojo?', answers:['Marte','Venus','Urano'], correct:0, explain:'Marte parece rojizo por los minerales de hierro oxidados de su superficie.' },
  { q:'¿Cuál es el planeta más cercano al Sol?', answers:['Mercurio','Tierra','Saturno'], correct:0, explain:'Mercurio es el planeta que orbita más cerca del Sol.' },
  { q:'¿En qué cuerpo celeste viven los astronautas cuando llegan a la Luna?', answers:['En una estación lunar permanente','En módulos o vehículos especiales','En una ciudad subterránea'], correct:1, explain:'Las misiones usan módulos y vehículos diseñados para las condiciones lunares.' },
  { q:'¿Qué planeta tiene una atmósfera muy densa y es el más caliente?', answers:['Venus','Neptuno','Mercurio'], correct:0, explain:'La atmósfera de Venus atrapa mucho calor mediante un intenso efecto invernadero.' },
  { q:'¿Cómo se llama la galaxia donde está nuestro sistema solar?', answers:['Andrómeda','Vía Láctea','Galaxia del Sombrero'], correct:1, explain:'Nuestro sistema solar forma parte de la Vía Láctea.' },
  { q:'¿Qué objeto orbita la Tierra de forma natural?', answers:['La Luna','Fobos','Europa'], correct:0, explain:'La Luna es el satélite natural de la Tierra.' },
  { q:'¿Qué planeta gira muy inclinado, casi de lado?', answers:['Júpiter','Urano','Marte'], correct:1, explain:'Urano tiene una inclinación axial extrema y parece girar de lado.' },
  { q:'¿Qué nombre reciben las rocas espaciales que llegan a la superficie terrestre?', answers:['Meteoritos','Cometas','Nebulosas'], correct:0, explain:'Cuando un fragmento espacial llega al suelo, se llama meteorito.' }
]
const curiosities = [
  { number:'01', title:'Un día muy largo', category:'VENUS', text:'Venus tarda más en girar una vez sobre sí mismo que en completar una vuelta alrededor del Sol.' },
  { number:'02', title:'Atardeceres azules', category:'MARTE', text:'En Marte, el polvo de su atmósfera puede hacer que los atardeceres se vean azulados cerca del Sol.' },
  { number:'03', title:'Una tormenta gigante', category:'JÚPITER', text:'La Gran Mancha Roja es una enorme tormenta que lleva siendo observada desde hace siglos.' },
  { number:'04', title:'Anillos de hielo y roca', category:'SATURNO', text:'Los anillos de Saturno están compuestos por muchísimos fragmentos de hielo y roca, desde partículas diminutas hasta bloques mayores.' },
  { number:'05', title:'Un planeta helado', category:'URANO', text:'Urano es un gigante helado y su eje de rotación está inclinado aproximadamente 98 grados.' },
  { number:'06', title:'El Sol es una estrella', category:'EL SOL', text:'El Sol parece enorme y brillante porque está mucho más cerca de nosotros que las demás estrellas.' },
  { number:'07', title:'La Luna se aleja', category:'LA LUNA', text:'La Luna se aleja de la Tierra lentamente, a un ritmo de unos pocos centímetros por año.' },
  { number:'08', title:'Un día diferente', category:'MERCURIO', text:'En Mercurio, un ciclo entre un amanecer y el siguiente dura aproximadamente 176 días terrestres.' },
  { number:'09', title:'Vientos veloces', category:'NEPTUNO', text:'Neptuno registra algunos de los vientos más rápidos medidos en el sistema solar.' },
  { number:'10', title:'Hay agua fuera de la Tierra', category:'EUROPA', text:'Europa, una luna de Júpiter, tiene una capa de hielo y evidencias de un océano bajo su superficie.' },
  { number:'11', title:'La luz tarda en llegar', category:'ESPACIO', text:'La luz del Sol tarda alrededor de 8 minutos y 20 segundos en llegar a la Tierra.' },
  { number:'12', title:'Millones de estrellas', category:'VÍA LÁCTEA', text:'Nuestra galaxia contiene una enorme cantidad de estrellas; las estimaciones suelen situarse en cientos de miles de millones.' }
]
const currentQuestion = computed(() => questions[quizIndex.value])
const progress = computed(() => quizFinished.value ? 100 : ((quizIndex.value + 1) / questions.length) * 100)
function startMemory() {
  const symbols = ['planet','rocket','star','globe','planet','rocket','star','globe']
  memoryCards.value = symbols.map((symbol, id) => ({ symbol, id, open:false, matched:false })).sort(() => Math.random() - 0.5)
  firstCard.value = null; locked.value = false; matches.value = 0; memoryOpen.value = true
}
function flipCard(card) {
  if (locked.value || card.open || card.matched) return
  card.open = true
  if (!firstCard.value) { firstCard.value = card; return }
  if (firstCard.value.symbol === card.symbol) {
    firstCard.value.matched = true; card.matched = true; firstCard.value = null; matches.value++
    return
  }
  locked.value = true
  const previous = firstCard.value; firstCard.value = null
  setTimeout(() => { previous.open = false; card.open = false; locked.value = false }, 750)
}
function answer(index) {
  if (chosenAnswer.value !== null || quizFinished.value) return
  chosenAnswer.value = index
  if (index === currentQuestion.value.correct) score.value++
}
function nextQuestion() {
  if (chosenAnswer.value === null) return
  if (quizIndex.value < questions.length - 1) { quizIndex.value++; chosenAnswer.value = null }
  else quizFinished.value = true
}
function resetQuiz() { quizIndex.value = 0; chosenAnswer.value = null; quizFinished.value = false; score.value = 0 }
</script>

<template>
  <div>
    <header class="topbar">
      <a class="brand" href="#inicio" @click="menuOpen=false"><span class="brand-mark"><CosmicIcon name="rocket" :size="25" /></span><span>AVENTUREROS <b>DEL COSMOS</b></span></a>
      <button class="menu-toggle" aria-label="Abrir menú" :aria-expanded="menuOpen" @click="menuOpen=!menuOpen"><CosmicIcon name="menu" /></button>
      <nav :class="{ open: menuOpen }" aria-label="Módulos del OVA"><a href="#contenido" @click="menuOpen=false">Contenido</a><a href="#actividad" @click="menuOpen=false">Actividad</a><a href="#evaluacion" @click="menuOpen=false">Evaluación</a><a href="#recursos" @click="menuOpen=false">Recursos</a><a href="#creditos" @click="menuOpen=false">Créditos</a></nav>
    </header>

    <main>
      <section class="hero" id="inicio">
        <div class="hero-stars stars-one"></div><div class="hero-stars stars-two"></div>
        <div class="hero-copy"><span class="eyebrow">MISIÓN ESPACIAL: ¡COMENZAMOS!</span><h1>¡Aventureros<br><span>del Cosmos!</span></h1><p>¡Prepárate para una aventura fuera de este mundo! Descubre planetas increíbles, aprende curiosidades y conviértete en explorador del sistema solar.</p><div class="hero-actions"><a class="button primary" href="#contenido"><CosmicIcon name="globe" :size="19" /> Explorar el universo</a><a class="button secondary" href="#actividad"><CosmicIcon name="star" :size="19" /> Ir a jugar</a></div><div class="hero-note"><span class="pulse"></span> Una aventura para mentes curiosas</div></div>
        <div class="solar-art" aria-label="Ilustración del sistema solar"><div class="orbit orbit-a"></div><div class="orbit orbit-b"></div><div class="orbit orbit-c"></div><div class="sun"></div><div class="planet p-mercury"></div><div class="planet p-venus"></div><div class="planet p-earth"></div><div class="planet p-mars"></div><div class="planet p-jupiter"></div><div class="planet p-saturn"></div><div class="planet p-uranus"></div><div class="planet p-neptune"></div><div class="astronaut"><CosmicIcon name="rocket" :size="34" /></div><div class="sparkle sp1">✦</div><div class="sparkle sp2">✧</div></div>
        <div class="scroll-hint">DESLIZA PARA DESCUBRIR <span>↓</span></div>
      </section>

      <section class="section intro" id="contenido"><div class="section-heading"><span class="eyebrow">MÓDULO 1 · CONTENIDO</span><h2>Conoce a nuestros <span>vecinos espaciales</span></h2><p>El sistema solar está lleno de mundos sorprendentes. ¡Selecciona un planeta para conocerlo!</p></div>
        <div class="learning-goal"><span class="goal-icon"><CosmicIcon name="star" :size="22" /></span><div><strong>Objetivo de aprendizaje</strong><p>Reconocer los planetas del sistema solar y describir algunas de sus características mediante la exploración de contenidos, curiosidades y actividades interactivas.</p></div></div>
        <div class="planet-grid"><button v-for="planet in planets" :key="planet.name" class="planet-card" :class="[{selected:selectedPlanet?.name===planet.name}, planet.color+'-card']" @click="selectedPlanet=planet"><span class="planet-visual" :class="planet.color"><CosmicIcon v-if="planet.icon==='globe'||planet.icon==='planet'" :name="planet.icon" :size="34" /><span v-else></span></span><span class="planet-name">{{ planet.name }}</span><small>{{ planet.subtitle }}</small><span class="card-arrow">↗</span></button></div>
        <div class="planet-detail" aria-live="polite"><div class="detail-icon"><CosmicIcon :name="selectedPlanet?.icon==='rocket'?'rocket':selectedPlanet?.icon==='globe'?'globe':'planet'" :size="34" /></div><div><span class="eyebrow">FICHA DEL EXPLORADOR</span><h3>{{ selectedPlanet ? selectedPlanet.title : '¡Elige un planeta!' }}</h3><p>{{ selectedPlanet ? selectedPlanet.text : 'Presiona cualquiera de las tarjetas para descubrir un dato interesante.' }}</p></div></div>
      </section>

      <section class="section curiosities-section" id="curiosidades"><div class="section-heading"><span class="eyebrow">CONTENIDO COMPLEMENTARIO · CURIOSIDADES</span><h2>12 curiosidades <span>del cosmos</span></h2><p>Pequeños grandes descubrimientos para alimentar tu curiosidad. ¡Cada mundo tiene una historia!</p></div><div class="curiosity-grid"><article v-for="fact in curiosities" :key="fact.number" class="curiosity-card"><div class="curiosity-number">{{ fact.number }}</div><span class="curiosity-category">{{ fact.category }}</span><h3>{{ fact.title }}</h3><p>{{ fact.text }}</p></article></div></section>

      <section class="games-section section" id="actividad"><div class="section-heading"><span class="eyebrow">MÓDULO 2 · ACTIVIDAD</span><h2>¡Aprender también es <span>jugar!</span></h2><p>Completa los retos y demuestra todo lo que sabes del cosmos.</p></div>
        <div class="game-grid"><article class="game-card game-purple"><div class="game-illustration"><CosmicIcon name="brain" :size="48" /></div><div><span class="game-tag">RETO 01</span><h3>Memoria cósmica</h3><p>¡Pon a prueba tu memoria con los símbolos del espacio!</p><button class="button game-button" @click="startMemory">Jugar ahora <CosmicIcon name="arrow" :size="17" /></button></div></article><article class="game-card game-blue"><div class="game-illustration"><CosmicIcon name="rocket" :size="48" /></div><div><span class="game-tag">RETO 02</span><h3>Pregunta espacial</h3><p>Responde preguntas y gana insignias de explorador.</p><a class="button game-button" href="#evaluacion">Comenzar reto <CosmicIcon name="arrow" :size="17" /></a></div></article></div>
        <div v-if="memoryOpen" class="memory-panel"><div class="memory-top"><div><span class="eyebrow">RETO DE MEMORIA</span><h3>Encuentra las parejas</h3></div><button class="close-btn" aria-label="Cerrar juego" @click="memoryOpen=false"><CosmicIcon name="close" /></button></div><p>Voltea las cartas y encuentra los dos símbolos iguales.</p><div class="memory-grid"><button v-for="card in memoryCards" :key="card.id" class="memory-card" :class="{open:card.open,matched:card.matched}" :aria-label="card.open||card.matched ? 'Carta revelada' : 'Carta oculta'" @click="flipCard(card)"><CosmicIcon v-if="card.open||card.matched" :name="card.symbol" :size="29" /><span v-else class="card-star">✦</span></button></div><div class="memory-status" aria-live="polite">{{ matches===4 ? '¡Excelente! Encontraste todas las parejas.' : `Parejas encontradas: ${matches} de 4` }}</div><button class="button primary" @click="startMemory">Volver a jugar</button></div>
      </section>

      <section class="quiz-section section" id="evaluacion"><div class="section-heading"><span class="eyebrow">MÓDULO 3 · EVALUACIÓN</span><h2>Demuestra lo que <span>aprendiste</span></h2><p>Responde el cuestionario y revisa tu resultado al finalizar.</p></div><div class="quiz-card"><div class="quiz-copy"><span class="eyebrow">EXAMEN DE EXPLORADOR</span><h2>¿Cuánto sabes del <span>espacio?</span></h2><p>Responde estas preguntas para comprobar tus conocimientos. ¡Cada descubrimiento cuenta!</p><div class="quiz-progress"><span :style="{width:progress+'%'}"></span></div><small>{{ quizFinished ? 'Reto completado' : `Pregunta ${quizIndex+1} de ${questions.length}` }}</small></div><div class="quiz-question"><div class="question-number" v-if="!quizFinished">{{ String(quizIndex+1).padStart(2,'0') }} <span>/ {{ String(questions.length).padStart(2, '0') }}</span></div><div class="question-number" v-else><CosmicIcon name="trophy" :size="30" /></div><template v-if="!quizFinished"><h3>{{ currentQuestion.q }}</h3><div class="answers"><button v-for="(option,index) in currentQuestion.answers" :key="option" class="answer" :class="{correct:chosenAnswer!==null&&index===currentQuestion.correct,wrong:chosenAnswer===index&&index!==currentQuestion.correct}" :disabled="chosenAnswer!==null" @click="answer(index)">{{ option }}</button></div><p class="feedback" aria-live="polite">{{ chosenAnswer===null ? '' : chosenAnswer===currentQuestion.correct ? currentQuestion.explain : `¡Buen intento! La respuesta correcta es ${currentQuestion.answers[currentQuestion.correct]}.` }}</p><button class="button primary next-btn" :disabled="chosenAnswer===null" @click="nextQuestion">{{ quizIndex===questions.length-1 ? 'Ver resultado' : 'Siguiente pregunta' }} <CosmicIcon name="arrow" :size="17" /></button></template><template v-else><h3>¡Terminaste el reto espacial!</h3><p class="feedback">Tu puntuación: {{ score }} de {{ questions.length }} respuestas correctas. ¡Sigue explorando y aprendiendo!</p><button class="button primary" @click="resetQuiz">Volver a comenzar</button></template></div></div></section>

      <section class="section resources-section" id="recursos">
        <div class="section-heading"><span class="eyebrow">MÓDULO 4 · RECURSOS</span><h2>Herramientas para <span>seguir explorando</span></h2><p>Consulta estos materiales para ampliar lo aprendido en el OVA.</p></div>
        <div class="resource-grid">
          <article class="resource-card"><div class="resource-icon"><CosmicIcon name="globe" :size="30" /></div><div><span class="resource-type">SITIO EDUCATIVO</span><h3>NASA: Sistema solar</h3><p>Información, imágenes y datos sobre el Sol, los planetas y otros cuerpos celestes.</p><a href="https://science.nasa.gov/solar-system/" target="_blank" rel="noopener noreferrer">Visitar recurso ↗</a></div></article>
          <article class="resource-card"><div class="resource-icon"><CosmicIcon name="star" :size="30" /></div><div><span class="resource-type">GALERÍA MULTIMEDIA</span><h3>NASA Solar System Exploration</h3><p>Explora fotografías, misiones espaciales y contenidos multimedia del sistema solar.</p><a href="https://solarsystem.nasa.gov/" target="_blank" rel="noopener noreferrer">Visitar recurso ↗</a></div></article>
          <article class="resource-card"><div class="resource-icon"><CosmicIcon name="rocket" :size="30" /></div><div><span class="resource-type">RECURSO DE CONSULTA</span><h3>Agencia Espacial Europea</h3><p>Noticias y recursos para conocer la exploración espacial y sus descubrimientos.</p><a href="https://www.esa.int/" target="_blank" rel="noopener noreferrer">Visitar recurso ↗</a></div></article>
        </div>
        <p class="resource-note">Recomendación: utiliza estos enlaces como material complementario y verifica la fecha de publicación de la información que consultes.</p>
      </section>

      <section class="section credits-section" id="creditos">
        <div class="section-heading"><span class="eyebrow">MÓDULO 5 · CRÉDITOS</span><h2>Detrás de esta <span>aventura</span></h2><p>Este espacio identifica a las personas e instituciones responsables del Objeto Virtual de Aprendizaje.</p></div>
        <div class="credits-card">
          <div class="credits-symbol"><CosmicIcon name="rocket" :size="38" /></div>
          <div class="credits-details"><div><span>PROYECTO</span><strong>Aventureros del Cosmos</strong></div><div><span>TIPO DE RECURSO</span><strong>Objeto Virtual de Aprendizaje (OVA)</strong></div><div><span>AUTOR</span><strong>Santiado de Jesús Perales Doria</strong></div><div><span>INSTITUCIÓN</span><strong>Universidad de Córdoba</strong></div><div><span>PROGRAMA</span><strong>Informática</strong></div><div><span>ASIGNATURA</span><strong>Fundamentos de Programación</strong></div><div><span>DOCENTE</span><strong>Aly Benhur Culchac De La Vega</strong></div><div><span>TECNOLOGÍAS</span><strong>Vue 3, Nuxt 3, JavaScript, HTML y CSS</strong></div></div>
          <p class="credits-disclaimer">Datos académicos y de autoría del proyecto.</p>
        </div>
      </section>

      <section class="final-cta"><div class="cta-rocket"><CosmicIcon name="rocket" :size="45" /></div><div><span class="eyebrow">TU AVENTURA APENAS COMIENZA</span><h2>El cosmos te espera, explorador.</h2><p>¡Sigue aprendiendo, haciendo preguntas y descubriendo cosas nuevas!</p></div><a href="#inicio" class="button cta-button">Volver al inicio ↑</a></section>
    </main>
    <footer><a class="brand footer-brand" href="#inicio"><CosmicIcon name="rocket" :size="21" /> AVENTUREROS DEL COSMOS</a><span>OVA educativo · Contenido, actividad, evaluación, recursos y créditos.</span><a href="#creditos">Ver créditos ↑</a></footer>
  </div>
</template>
