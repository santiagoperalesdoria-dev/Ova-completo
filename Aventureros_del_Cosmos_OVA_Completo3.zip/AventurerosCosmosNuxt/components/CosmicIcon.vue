<script setup>
const props = defineProps({ name: { type: String, required: true }, size: { type: [Number, String], default: 28 } })
const paths = {
  rocket: '<path d="M12 2c3 2 5 5 5 9l-5 5-5-5c0-4 2-7 5-9Z"/><path d="m7 10-3 2-1 5 5-3M17 10l3 2 1 5-5-3M9 16l-1 5 4-2 4 2-1-5"/><circle cx="12" cy="8" r="1.7"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3.5 9h17M5 16h14M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  brain: '<path d="M12 5a3 3 0 0 0-5-2 4 4 0 0 0-4 6 4 4 0 0 0 1 6 4 4 0 0 0 5 5 3 3 0 0 0 3-2Z"/><path d="M12 5a3 3 0 0 1 5-2 4 4 0 0 1 4 6 4 4 0 0 1-1 6 4 4 0 0 1-5 5 3 3 0 0 1-3-2ZM8 7c2 0 3 2 2 4M5 13c2-1 4 0 4 2M16 7c-2 0-3 2-2 4M19 13c-2-1-4 0-4 2"/>',
  star: '<path d="m12 2 2.8 6.1 6.7.8-4.9 4.6 1.3 6.6-5.9-3.3-5.9 3.3 1.3-6.6-4.9-4.6 6.7-.8Z"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  trophy: '<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4ZM7 6H3v2a4 4 0 0 0 4 4M17 6h4v2a4 4 0 0 1-4 4"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  planet: '<circle cx="12" cy="12" r="6"/><ellipse cx="12" cy="12" rx="11" ry="3.5" transform="rotate(-25 12 12)"/>'
}
</script>
<template><svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" role="img" aria-hidden="true" v-html="paths[name] || paths.star" /></template>
