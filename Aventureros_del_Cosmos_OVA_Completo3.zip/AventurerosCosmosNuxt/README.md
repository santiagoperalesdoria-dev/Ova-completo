# Aventureros del Cosmos — Objeto Virtual de Aprendizaje (OVA)

OVA interactivo desarrollado con Nuxt 3 y Vue 3. Su propósito es apoyar el reconocimiento de los planetas del sistema solar mediante contenidos breves, curiosidades, actividades y evaluación.

## Módulos incluidos

1. **Contenido:** objetivo de aprendizaje, fichas interactivas de los ocho planetas y 12 curiosidades del cosmos.
2. **Actividad:** juego de memoria cósmica con ocho cartas, cuatro parejas, contador de parejas y opción para reiniciar.
3. **Evaluación:** cuestionario de 12 preguntas de selección múltiple, retroalimentación inmediata, indicador de avance, puntuación final y reinicio.
4. **Recursos:** enlaces de consulta a NASA y Agencia Espacial Europea para ampliar la información.
5. **Créditos:** ficha para completar autores, institución, programa, asignatura y docente.

La navegación superior permite acceder directamente a los cinco módulos. El diseño es adaptable a pantallas de escritorio, tabletas y móviles.

## Requisitos
- Node.js 20 o superior
- npm

## Instalación y ejecución
Abre una terminal en esta carpeta y ejecuta:

```bash
npm install
npm run dev
```

Abre la dirección local que indique Nuxt (normalmente `http://localhost:3000`).

## Compilación para producción

```bash
npm run build
npm run preview
```

## Personalización antes de entregar
En el módulo **Créditos**, reemplaza los campos entre corchetes por los nombres reales de los integrantes, institución, programa académico, asignatura y docente. Revisa también que los enlaces externos y las referencias se ajusten a las indicaciones de tu curso.

## Estructura
- `pages/index.vue`: estructura de la página, contenidos, actividades y evaluación.
- `components/CosmicIcon.vue`: iconos SVG propios.
- `assets/css/main.css`: estilos y diseño responsive.
- `nuxt.config.ts`: configuración de Nuxt.

No se utilizan bibliotecas externas de iconos ni emojis del sistema operativo.
